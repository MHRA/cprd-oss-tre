import datetime
import logging
import os

import azure.functions as func

from azure.identity import ManagedIdentityCredential
from azure.keyvault.certificates import CertificateClient
from notifications_python_client.notifications import NotificationsAPIClient

def main(mytimer: func.TimerRequest) -> None:
    if mytimer.past_due:
        logging.info('The timer is past due!')

    # Read defined environment variables.
    MANAGED_IDENTITY_CLIENT_ID = os.getenv("MANAGED_IDENTITY_CLIENT_ID")
    VAULT_URL = os.getenv("VAULT_URL")
    NEXUS_CERT_NAME = os.getenv("NEXUS_CERT_NAME")
    TIME_DELTA_DAYS = os.getenv("TIME_DELTA_DAYS")
    NOTIFY_UK_API_KEY = os.getenv("NOTIFY_UK_API_KEY")
    NOTIFY_UK_TEMPLATE_ID_CERTS = os.getenv("NOTIFY_UK_TEMPLATE_ID_CERTS")

    # For running locally, it's better to use the DefaultAzureCredential() class.
    # In this case we must also import DefaultAzureCredential from azure.identity.
    # credential = DefaultAzureCredential(managed_identity_client_id=MANAGED_IDENTITY_CLIENT_ID)
    
    # Authenticate using Managed Identity.
    credential = ManagedIdentityCredential(client_id=MANAGED_IDENTITY_CLIENT_ID)
    certificate_client = CertificateClient(vault_url=VAULT_URL, credential=credential)

    # Retrieve the certificate and its expiration date.
    certificate = certificate_client.get_certificate(NEXUS_CERT_NAME)
    NEXUS_CERT_EXPIRE_DATE = certificate.properties.expires_on
    
    # Set comparison date and time threshold.
    COMPARISON_DATE = datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc)
    TIME_DELTA = datetime.timedelta(days=int(TIME_DELTA_DAYS))

    logging.info('Python timer trigger function ran at %s', COMPARISON_DATE.isoformat())

    # Check if Notify UK values passed were correct.
    if NOTIFY_UK_API_KEY == None or NOTIFY_UK_TEMPLATE_ID == None:
        logging.info("Variable NOTIFY_UK_API_KEY or NOTIFY_UK_TEMPLATE_ID is not set.")
    
    else:
        if NEXUS_CERT_EXPIRE_DATE - COMPARISON_DATE <= TIME_DELTA:
            logging.info(f"Certificate {NEXUS_CERT_NAME} to expire in <= {TIME_DELTA_DAYS} days")

            personalisation_data = {
                "message": "This is my text email message."
            }

            notifications_client = NotificationsAPIClient(NOTIFY_UK_API_KEY)
            
            #try:
                #response = notifications_client.send_email_notification(
                    #email_address = 'miguel.dasilva@emeal.nttdata.com',
                    #template_id = NOTIFY_UK_TEMPLATE_ID,
                    #personalisation = personalisation_data
                #)            
            #
            #except:
                #raise Exception("Unable to send email using Notify UK")
            #
            #return response

        else:
            logging.info(f"Certificate {NEXUS_CERT_NAME} to expire in > {TIME_DELTA_DAYS} days")
